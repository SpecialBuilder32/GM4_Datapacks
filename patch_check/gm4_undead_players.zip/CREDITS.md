# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- SunderB

## Icon Design
- Hozz
