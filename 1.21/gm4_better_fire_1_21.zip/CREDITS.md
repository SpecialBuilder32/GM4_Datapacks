# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated By
- [Bloo](https://twitter.com/Bloo_dev)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
