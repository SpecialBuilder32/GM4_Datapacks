# Credits

## Creators
- [Bloo](https://bsky.app/profile/bloo.boo)
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
