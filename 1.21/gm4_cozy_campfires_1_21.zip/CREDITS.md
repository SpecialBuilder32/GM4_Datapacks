# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
