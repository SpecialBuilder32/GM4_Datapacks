# Credits

## Creator
- Epyon

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
