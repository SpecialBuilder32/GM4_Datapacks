# Credits

## Creators
- [BPR](https://bsky.app/profile/bpr02.com)
- [Denniss](https://github.com/Dennis-0)
- [Lue](https://github.com/Luexa)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
