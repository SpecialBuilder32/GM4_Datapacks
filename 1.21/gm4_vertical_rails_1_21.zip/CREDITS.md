# Credits

## Creators
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
- [SiberianHat](https://twitter.com/SiberianHat)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Kruthers](https://twitter.com/Pandakruthers)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
