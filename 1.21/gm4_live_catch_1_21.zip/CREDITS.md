# Credits

## Creator
- [MichaelModulo](https://www.michaelmodulo.dev/page/links.html)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
