# Credits

## Creator
- [MichaelMiner137](https://linktr.ee/MichaelMiner137)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
