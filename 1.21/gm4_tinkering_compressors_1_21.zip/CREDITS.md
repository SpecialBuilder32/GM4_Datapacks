# Credits

## Creator
- [SirSheepe](https://twitter.com/SirSheepe)

## Updated by
- [MichaelMiner137](https://linktr.ee/MichaelMiner137)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
