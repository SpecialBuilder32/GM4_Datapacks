# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
