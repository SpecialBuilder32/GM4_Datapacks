# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Misode](https://bsky.app/profile/misode.dev)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
