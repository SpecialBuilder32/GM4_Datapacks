# Credits

## Creator
- [Scommander](https://github.com/Scommander)

## Updated by
- [Denniss](https://github.com/Dennis-0)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
