# Credits

## Creator
- Kattacka

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
