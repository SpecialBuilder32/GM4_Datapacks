# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- Hozz

## Textures
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)
