# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated By
- [Andante](https://bsky.app/profile/andante.dev)
- [Kroppeb](https://tech.lgbt/@Kroppeb)
- [Misode](https://bsky.app/profile/misode.dev)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures By
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- Hozz
