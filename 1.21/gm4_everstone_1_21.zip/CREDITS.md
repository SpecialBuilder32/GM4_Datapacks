# Credits

## Creators
- [Denniss](https://github.com/Dennis-0)
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
