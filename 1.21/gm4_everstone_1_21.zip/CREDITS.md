# Credits

## Creators
- [Denniss](https://twitter.com/Dennis2p_)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
