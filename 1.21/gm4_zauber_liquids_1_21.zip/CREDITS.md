# Credits

## Creators
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [JP12](https://github.com/jpeterik12)

## Textures by
- Vilder50
- Hozz

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
