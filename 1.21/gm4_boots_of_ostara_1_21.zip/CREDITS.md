# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)
- [catter1](https://bsky.app/profile/catter.dev)

## Icon Design
- Hozz
