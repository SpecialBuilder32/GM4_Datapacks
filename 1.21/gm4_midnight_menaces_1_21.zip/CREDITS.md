# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
