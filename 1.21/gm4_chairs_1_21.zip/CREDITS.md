# Credits

## Creator
- [Denniss](https://github.com/Dennis-0)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
