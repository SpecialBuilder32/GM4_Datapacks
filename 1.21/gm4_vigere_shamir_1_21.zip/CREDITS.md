# Credits

## Creator
- [Thanathor](https://bsky.app/profile/thanathor.bsky.social)
- TheEpyonProject

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
