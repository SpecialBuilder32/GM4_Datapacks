# Credits

## Creator
- [15Redstones](https://twitter.com/15Redstones)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)
- TheEpyonProject

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
