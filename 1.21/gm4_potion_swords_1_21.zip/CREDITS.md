# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
