# Credits

## Creators
- [BPR](https://bsky.app/profile/bpr02.com)
- TheEpyonProject

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
