# Credits

## Creators
- [Denniss](https://github.com/Dennis-0)
- [Nik3141](https://youtube.com/channel/UCgKd6elt0L3w-d7ryLw-7HQ)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
