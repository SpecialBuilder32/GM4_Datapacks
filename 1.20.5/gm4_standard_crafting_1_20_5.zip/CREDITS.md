# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
