# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Misode](https://twitter.com/misode_)
- [Andante](https://twitter.com/andantett)

## Icon Design
- JonPot
