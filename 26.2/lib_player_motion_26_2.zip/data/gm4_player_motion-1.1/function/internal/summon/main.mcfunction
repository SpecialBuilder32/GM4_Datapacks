#> gm4_player_motion-1.1:internal/summon/main
$execute facing ~$(motion_x) ~$(motion_y) ~$(motion_z) run function gm4_player_motion-1.1:internal/summon/crystal with storage gm4_player_motion:math
