execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. if score gm4_machines load.status matches 1 if score gm4_machines_minor load.status matches 5.. run scoreboard players set gm4_smelteries load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. if score gm4_machines load.status matches 1 if score gm4_machines_minor load.status matches 5.. run scoreboard players set gm4_smelteries_minor load.status 9
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Smelteries",id:"gm4_smelteries",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Smelteries",id:"gm4_smelteries",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 9.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Smelteries",id:"gm4_smelteries",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute unless score gm4_machines load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Smelteries",id:"gm4_smelteries",require:"lib_machines",require_id:"gm4_machines"}
execute if score gm4_machines load.status matches 1.. unless score gm4_machines load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Smelteries",id:"gm4_smelteries",require:"lib_machines",require_id:"gm4_machines",require_ver:"1.5.0"}
execute if score gm4_machines load.status matches 1 unless score gm4_machines_minor load.status matches 5.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Smelteries",id:"gm4_smelteries",require:"lib_machines",require_id:"gm4_machines",require_ver:"1.5.0"}
execute unless score gm4_smelteries load.status matches 1.. run scoreboard players set gm4_smelteries load.status -1

execute if score gm4_smelteries load.status matches 1 run function gm4_smelteries:init
execute unless score gm4_smelteries load.status matches 1 run schedule clear gm4_smelteries:main
