execute if entity @s[advancements={gm4_guidebook:slime_fests/unlock/description=true}] run function gm4_guidebook:slime_fests/rewards/unlock/description
return 1
