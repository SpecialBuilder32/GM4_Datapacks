execute if entity @s[advancements={gm4_guidebook:sandy_husks/unlock/description=true}] run function gm4_guidebook:sandy_husks/rewards/unlock/description
return 1
