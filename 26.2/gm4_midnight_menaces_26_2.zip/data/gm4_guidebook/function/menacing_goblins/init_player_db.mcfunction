execute if entity @s[advancements={gm4_guidebook:menacing_goblins/unlock/description=true}] run function gm4_guidebook:menacing_goblins/rewards/unlock/description
return 1
