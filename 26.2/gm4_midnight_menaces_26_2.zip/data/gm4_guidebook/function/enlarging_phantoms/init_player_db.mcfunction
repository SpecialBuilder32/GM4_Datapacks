execute if entity @s[advancements={gm4_guidebook:enlarging_phantoms/unlock/description=true}] run function gm4_guidebook:enlarging_phantoms/rewards/unlock/description
return 1
