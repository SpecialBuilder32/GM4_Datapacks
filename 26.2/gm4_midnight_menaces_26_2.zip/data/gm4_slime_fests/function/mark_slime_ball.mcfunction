# @s = slime_ball item on the ground
# at world spawn
# called by event

scoreboard players add @s gm4_reslimify 1
execute at @s run particle minecraft:entity_effect{color:[0.0d,1.0d,0.1d,1.0d]} ~ ~ ~ 0 0 0 1 0
