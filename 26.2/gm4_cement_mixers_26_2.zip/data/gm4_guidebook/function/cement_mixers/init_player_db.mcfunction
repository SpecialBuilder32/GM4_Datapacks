execute if entity @s[advancements={gm4_guidebook:cement_mixers/unlock/usage=true}] run function gm4_guidebook:cement_mixers/rewards/unlock/usage
return 1
