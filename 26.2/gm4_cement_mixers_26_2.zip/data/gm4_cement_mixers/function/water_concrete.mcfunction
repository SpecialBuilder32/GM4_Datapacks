# run from item_fill
# @s = liquid tank at @s




















execute if items block ~ ~ ~ container.0 minecraft:black_concrete_powder run function gm4_cement_mixers:item_fill/black_concrete
execute if items block ~ ~ ~ container.0 minecraft:blue_concrete_powder run function gm4_cement_mixers:item_fill/blue_concrete
execute if items block ~ ~ ~ container.0 minecraft:brown_concrete_powder run function gm4_cement_mixers:item_fill/brown_concrete
execute if items block ~ ~ ~ container.0 minecraft:cyan_concrete_powder run function gm4_cement_mixers:item_fill/cyan_concrete
execute if items block ~ ~ ~ container.0 minecraft:gray_concrete_powder run function gm4_cement_mixers:item_fill/gray_concrete

execute if items block ~ ~ ~ container.0 minecraft:green_concrete_powder run function gm4_cement_mixers:item_fill/green_concrete
execute if items block ~ ~ ~ container.0 minecraft:light_blue_concrete_powder run function gm4_cement_mixers:item_fill/light_blue_concrete
execute if items block ~ ~ ~ container.0 minecraft:light_gray_concrete_powder run function gm4_cement_mixers:item_fill/light_gray_concrete
execute if items block ~ ~ ~ container.0 minecraft:lime_concrete_powder run function gm4_cement_mixers:item_fill/lime_concrete
execute if items block ~ ~ ~ container.0 minecraft:magenta_concrete_powder run function gm4_cement_mixers:item_fill/magenta_concrete
execute if items block ~ ~ ~ container.0 minecraft:orange_concrete_powder run function gm4_cement_mixers:item_fill/orange_concrete
execute if items block ~ ~ ~ container.0 minecraft:pink_concrete_powder run function gm4_cement_mixers:item_fill/pink_concrete
execute if items block ~ ~ ~ container.0 minecraft:purple_concrete_powder run function gm4_cement_mixers:item_fill/purple_concrete
execute if items block ~ ~ ~ container.0 minecraft:red_concrete_powder run function gm4_cement_mixers:item_fill/red_concrete
execute if items block ~ ~ ~ container.0 minecraft:white_concrete_powder run function gm4_cement_mixers:item_fill/white_concrete
execute if items block ~ ~ ~ container.0 minecraft:yellow_concrete_powder run function gm4_cement_mixers:item_fill/yellow_concrete
execute if items block ~ ~ ~ container.0 #gm4_cement_mixers:dirt run function gm4_cement_mixers:item_fill/mud
