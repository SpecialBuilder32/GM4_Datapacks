execute if score lively_lily_pads gm4_earliest_version matches ..299999 run function gm4_lively_lily_pads:upgrade_paths/3.0
execute if score lively_lily_pads gm4_earliest_version matches ..300999 run function gm4_lively_lily_pads:upgrade_paths/3.1
execute if score lively_lily_pads gm4_earliest_version matches ..302999 run function gm4_lively_lily_pads:upgrade_paths/3.3
execute if score lively_lily_pads gm4_earliest_version matches ..302999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
