execute if entity @s[advancements={gm4_guidebook:ender_bolt_shamir/unlock/usage=true}] run function gm4_guidebook:ender_bolt_shamir/rewards/unlock/usage
return 1
