execute if entity @s[advancements={gm4_guidebook:vibro_shamir/unlock/usage=true}] run function gm4_guidebook:vibro_shamir/rewards/unlock/usage
return 1
