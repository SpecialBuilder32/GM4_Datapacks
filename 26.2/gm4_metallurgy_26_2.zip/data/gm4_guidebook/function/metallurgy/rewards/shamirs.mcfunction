tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Metallurgy]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Metallurgy",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.metallurgy",fallback:"Introduces 4 custom ores, 6 custom metals and a whole bunch of custom enchants to the game. Cast metal bands that hold magical properties called 'Shamirs' and upgrade your armour and tools with them!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:metallurgy/display/shamirs
advancement grant @s only gm4_guidebook:metallurgy/unlock/casting
function gm4_guidebook:metallurgy/rewards/unlock/shamirs
