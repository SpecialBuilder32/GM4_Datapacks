execute if entity @s[advancements={gm4_guidebook:musical_shamir/unlock/usage=true}] run function gm4_guidebook:musical_shamir/rewards/unlock/usage
return 1
