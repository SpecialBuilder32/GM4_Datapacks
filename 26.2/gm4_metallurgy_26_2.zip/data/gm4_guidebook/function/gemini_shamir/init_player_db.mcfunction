execute if entity @s[advancements={gm4_guidebook:gemini_shamir/unlock/usage=true}] run function gm4_guidebook:gemini_shamir/rewards/unlock/usage
return 1
