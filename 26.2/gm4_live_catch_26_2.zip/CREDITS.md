# Credits

## Creator
- [Modulorium](https://www.modulorium.dev)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
