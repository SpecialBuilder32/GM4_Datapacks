tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Live Catch]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Live Catch",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.live_catch",fallback:"Catch live fish when fishing! But watch out for Pufferfish, those might make for a nasty surprise!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:live_catch/display/description
function gm4_guidebook:live_catch/rewards/unlock/description
