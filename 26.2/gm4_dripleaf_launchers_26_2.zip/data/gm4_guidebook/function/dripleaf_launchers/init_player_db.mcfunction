execute if entity @s[advancements={gm4_guidebook:dripleaf_launchers/unlock/description=true}] run function gm4_guidebook:dripleaf_launchers/rewards/unlock/description
return 1
