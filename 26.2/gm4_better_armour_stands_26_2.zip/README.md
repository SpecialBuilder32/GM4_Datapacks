# <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="GM4 Logo" width="32" /> Better Armour Stands by Gamemode 4

Ever felt like Armour Stands looked a bit boring? Better Armour Stands lets your Armour Stands strike all the poses you want! Simply use a Book and Quill to edit Armour Stands. 

<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/gm4_better_armour_stands/images/better_armour_stands.webp" alt="Better Armour Stands Example" width="350"/>   

### Features
- All armour stands have arms by default
- Write commands into a Book and Quill to control your armour stands
    - [Click Here](https://wiki.gm4.co/wiki/Better_Armour_Stands#Codes) to see a full list of codes
- Copy and Paste poses
- Make custom statues
- Survival Friendly!

### Posing Codes
|Code       |Description                                    |
| :---:     |-----------------------------------------------|
|`arms`     |toggle arm visibility                          |
|`base`     |toggle base-plate visibility                   |
|`size`     |toggle small/tall size                         |
|`gravity`  |toggle gravity                                 |
|`visible`  |toggle invisibility                            |
|`turn`     |slowly spin right or left                      |
|`lock`     |disable interactions                           |
|`unlock`   |enable interactions                            |
|`pose`     |select and move body parts                     |
|`default`  |restore the default pose                       |
|`copy`     |copies pose to armour stand in offhand          |
|`paste`    |pastes pose from armour stand in offhand        |
|`equip`    |transfer player offhand to selected body part  |

### Expansion Packs
Want some preset poses? Download the [Poses Pack Expansion](https://gm4.co/modules/poses-pack)

Add particles to your builds with the [Particles Pack Expansion](https://gm4.co/modules/particles-pack)

### More Info
[<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/youtube_logo.png" alt="Youtube Logo" width="40" align="center"/> **Watch on Youtube**](https://www.youtube.com/watch?v=ZBqmGpAXqmw)

[<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_wiki_logo.png" alt="Gamemode 4 Wiki Logo" width="40" align="center"/> **Read the Wiki**](https://wiki.gm4.co/wiki/Better_Armour_Stands)

### Credits
- Creator: [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
- Updated by: [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social), [Misode](https://bsky.app/profile/misode.dev), [Denniss](https://github.com/Dennis-0)
- Icon Design: [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

---
## About Gamemode 4 <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="Gamemode 4 Logo" width="20"/>
Gamemode 4 is a series of command-powered creations that are designed to change and enhance the survival experience. All of our modules are designed to work together flawlessly, and are balanced for usage in a survival setting. Pick and choose your favorites from our [website](https://gm4.co), or wherever you get datapacks.