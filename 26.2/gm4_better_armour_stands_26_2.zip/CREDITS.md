# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Misode](https://bsky.app/profile/misode.dev)
- [Denniss](https://github.com/Dennis-0)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
