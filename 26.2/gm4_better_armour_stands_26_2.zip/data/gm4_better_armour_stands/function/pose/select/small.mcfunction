# @s = armor_stand to be modified
# at @s
# run from pose/select and default/part

# base
summon minecraft:area_effect_cloud ~ ~-0.25 ~ {Radius:0.2f,Tags:["gm4_bas_base"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}

# head
summon minecraft:area_effect_cloud ~ ~0.75 ~ {Radius:0.08f,Tags:["gm4_bas_head"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}

# body
summon minecraft:area_effect_cloud ~ ~0.25 ~ {Radius:0.09f,Tags:["gm4_bas_body"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}

# arms
execute positioned ~ ~0.3 ~ run summon minecraft:area_effect_cloud ^0.18 ^ ^ {Radius:0.09f,Tags:["gm4_bas_left_arm"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}
execute positioned ~ ~0.3 ~ run summon minecraft:area_effect_cloud ^-0.18 ^ ^ {Radius:0.09f,Tags:["gm4_bas_right_arm"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}

# legs
summon minecraft:area_effect_cloud ^0.1 ^ ^ {Radius:0.1f,Tags:["gm4_bas_left_leg"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}
summon minecraft:area_effect_cloud ^-0.1 ^ ^ {Radius:0.1f,Tags:["gm4_bas_right_leg"],Duration:0,WaitTime:2,custom_particle:{type:"minecraft:item",item:"minecraft:armor_stand"}}
