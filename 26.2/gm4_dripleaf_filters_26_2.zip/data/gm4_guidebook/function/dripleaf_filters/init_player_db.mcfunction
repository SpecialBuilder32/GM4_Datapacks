execute if entity @s[advancements={gm4_guidebook:dripleaf_filters/unlock/usage=true}] run function gm4_guidebook:dripleaf_filters/rewards/unlock/usage
return 1
