execute if entity @s[advancements={gm4_guidebook:block_compressors/unlock/crafting=true}] run function gm4_guidebook:block_compressors/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:block_compressors/unlock/usage=true}] run function gm4_guidebook:block_compressors/rewards/unlock/usage
return 1
