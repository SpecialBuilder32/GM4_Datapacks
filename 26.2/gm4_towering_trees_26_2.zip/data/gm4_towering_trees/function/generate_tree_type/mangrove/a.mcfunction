# generates the tree - mega mangrove
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/mangrove/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~32 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 132 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~15 ~ run clone ~ ~ ~ ~15 ~17 ~13 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 4032 run return fail

# optional feature
function gm4_towering_trees:generate_tree_type/mangrove/extra

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:mangrove/a ~-5 ~ ~-8
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:mangrove/a ~6 ~ ~9 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:mangrove/a ~9 ~ ~-5 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:mangrove/a ~-8 ~ ~6 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
