# generates the tree - mega cherry
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/cherry/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~16 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 68 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~4 ~ run clone ~ ~ ~ ~23 ~12 ~15 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 4992 run return fail

# optional feature
place feature gm4_towering_trees:pink_petals ~ ~1 ~

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:cherry/c ~-15 ~ ~-7
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:cherry/c ~16 ~ ~8 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:cherry/c ~8 ~ ~-15 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:cherry/c ~-7 ~ ~16 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
