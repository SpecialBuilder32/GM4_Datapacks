# generates the tree - mega birch
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/birch/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~32 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 132 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~12 ~ run clone ~ ~ ~ ~9 ~20 ~9 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 2100 run return fail

# optional feature
#

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:birch/c ~-4 ~ ~-4
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:birch/c ~5 ~ ~5 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:birch/c ~5 ~ ~-4 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:birch/c ~-4 ~ ~5 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
