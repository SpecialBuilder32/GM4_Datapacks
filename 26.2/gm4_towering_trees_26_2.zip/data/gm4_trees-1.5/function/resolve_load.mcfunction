execute if score gm4_trees load.status matches 1 if score gm4_trees_minor load.status matches 5 run function gm4_trees-1.5:load
execute unless score gm4_trees load.status matches 1 run schedule clear gm4_trees-1.5:tick
execute unless score gm4_trees_minor load.status matches 5 run schedule clear gm4_trees-1.5:tick
execute unless score gm4_trees load.status matches 1 run schedule clear gm4_trees-1.5:main
execute unless score gm4_trees_minor load.status matches 5 run schedule clear gm4_trees-1.5:main
