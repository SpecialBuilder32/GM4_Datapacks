execute if entity @s[advancements={gm4_guidebook:zauber_liquids/unlock/description=true}] run function gm4_guidebook:zauber_liquids/rewards/unlock/description
return 1
