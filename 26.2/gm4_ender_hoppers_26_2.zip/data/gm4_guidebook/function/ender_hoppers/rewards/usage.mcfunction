tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Ender Hoppers]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Ender Hoppers",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.ender_hoppers",fallback:"Create special hoppers that teleport nearby items to them.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:ender_hoppers/display/usage
function gm4_guidebook:ender_hoppers/rewards/unlock/usage
