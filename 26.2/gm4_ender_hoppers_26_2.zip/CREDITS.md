# Credits

## Creator
- Elemend

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
