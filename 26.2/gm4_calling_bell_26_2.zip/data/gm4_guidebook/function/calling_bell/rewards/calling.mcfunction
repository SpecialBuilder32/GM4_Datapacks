tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Calling Bell]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Calling Bell",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.calling_bell",fallback:"Summon a Wandering Trader by using an Emerald on a Bell.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:calling_bell/display/calling
function gm4_guidebook:calling_bell/rewards/unlock/calling
