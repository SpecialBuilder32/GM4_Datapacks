# Credits

## Creator
- TheEpyonProject

## Updated By
- [runcows](https://bsky.app/profile/runcows.bsky.social)

## Icon Design
- Hozz
