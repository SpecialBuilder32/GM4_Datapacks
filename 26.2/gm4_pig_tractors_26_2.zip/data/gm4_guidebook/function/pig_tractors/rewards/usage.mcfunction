tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Pig Tractors]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Pig Tractors",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.pig_tractors",fallback:"Ride pigs through fields to quickly harvest and plant crops! Who knows, maybe you will even dig up some useful things in the process.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:pig_tractors/display/usage
advancement grant @s only gm4_guidebook:pig_tractors/unlock/description
function gm4_guidebook:pig_tractors/rewards/unlock/usage
