execute if entity @s[advancements={gm4_guidebook:sweethearts/unlock/description=true}] run function gm4_guidebook:sweethearts/rewards/unlock/description
return 1
