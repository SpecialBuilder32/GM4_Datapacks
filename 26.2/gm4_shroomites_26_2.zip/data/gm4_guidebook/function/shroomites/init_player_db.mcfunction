execute if entity @s[advancements={gm4_guidebook:shroomites/unlock/description=true}] run function gm4_guidebook:shroomites/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:shroomites/unlock/spreading=true}] run function gm4_guidebook:shroomites/rewards/unlock/spreading
return 1
