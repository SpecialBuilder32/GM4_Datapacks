scoreboard objectives add gm4_count dummy
scoreboard objectives add gm4_brewing_data dummy

schedule function gm4_brewing-1.5:main 9t
execute unless score brewing gm4_earliest_version matches ..105001 run scoreboard players set brewing gm4_earliest_version 105001


data modify storage gm4:log versions append value {id:"gm4_brewing",module:"lib_brewing",version:"1.5.X",from:"Potion Liquids"}
