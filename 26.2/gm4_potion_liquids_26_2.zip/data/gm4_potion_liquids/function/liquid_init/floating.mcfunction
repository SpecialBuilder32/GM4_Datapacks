data merge block ~ ~ ~ {CustomName:{translate:"gm4.second",fallback:"%1$s",with:[{translate:"container.gm4.liquid_tank.floating",fallback:"Floating Potion Tank"},[{translate:"gui.gm4.liquid_tank",fallback:"",font:"gm4:container_gui",color:"white"},{translate:"container.gm4.liquid_tank.floating",fallback:"Floating Potion Tank",font:"gm4:default",color:"#404040"}]]}}
summon item_display ~ ~ ~ {CustomName:"gm4_liquid_tank_liquid_display",Tags:["gm4_liquid_tank_liquid_display","smithed.entity","smithed.strict"],item:{id:"player_head",count:1b,components:{"minecraft:profile":{id:[32752701,1442140104,-2121835220,212039422],properties:[{name:"textures",value:"eyd0ZXh0dXJlcyc6IHsnU0tJTic6IHsndXJsJzogJ2h0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmZiNjAxOGVjNzM4NWU4YTE5MTE3OWRjOWE1M2Y4MGY5NGQ4MjIzZWQ5YWEwNDgwMDcyNzdiNzUzMGNlZjgwZCd9fX0="}]}}},transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.2185f,0.0f],scale:[0.83d,0.83d,0.83d]},item_display:"head"}
data modify entity @s data.gm4_liquid_tanks.liquid_tag set value "gm4_lt_floating"
scoreboard players set @s gm4_lt_max 300
tag @s add gm4_lt_floating
tag @s remove gm4_lt_empty
