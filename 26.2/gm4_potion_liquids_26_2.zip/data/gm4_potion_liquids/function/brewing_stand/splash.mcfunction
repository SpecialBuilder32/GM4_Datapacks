loot spawn ~ ~ ~ loot gm4_potion_liquids:technical/brewing_stand/splash
