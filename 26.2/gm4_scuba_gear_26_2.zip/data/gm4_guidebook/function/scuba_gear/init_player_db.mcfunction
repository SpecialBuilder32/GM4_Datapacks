execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/crafting_flippers=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/crafting_flippers
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/crafting_wetsuit=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/crafting_wetsuit
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/crafting_scuba_helmet=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/crafting_scuba_helmet
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/crafting_scuba_tank=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/crafting_scuba_tank
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/usage_flippers=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/usage_flippers
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/usage_wetsuit=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/usage_wetsuit
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/usage_scuba_tank=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/usage_scuba_tank
execute if entity @s[advancements={gm4_guidebook:scuba_gear/unlock/usage_scuba_helmet=true}] run function gm4_guidebook:scuba_gear/rewards/unlock/usage_scuba_helmet
return 1
