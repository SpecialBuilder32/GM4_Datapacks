tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[SCUBA Gear]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"SCUBA Gear",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.scuba_gear",fallback:"Ease ocean exploration with craftable scuba gear!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:scuba_gear/display/crafting_wetsuit
function gm4_guidebook:scuba_gear/rewards/unlock/crafting_wetsuit
