# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Updated by
- TheEpyonProject

## Textures by
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
