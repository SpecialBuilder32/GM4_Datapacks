# places the liquid_minecart down
# @s = hopper_minecart with the liquid_minecart name
# located at @s
# run from gm4_liquid_minecarts:machine/verify_place_cart

scoreboard players set $placed_block gm4_machine_data 1

# summon new command block minecart
summon command_block_minecart ~ ~ ~ {Command:"execute if score @s gm4_lt_value matches 1.. run function gm4_liquid_minecarts:drain_minecart",CustomName:{text:"Liquid Minecart",italic:false},Tags:["gm4_liquid_minecart","gm4_liquid_minecart_empty","gm4_machine_cart","gm4_new_machine"],DisplayState:{Name:"minecraft:hopper"},DisplayOffset:1,Passengers:[{id:"minecraft:item_display",Tags:["gm4_liquid_minecart_display","gm4_machine_cart","smithed.entity","smithed.strict","gm4_new_machine"],item:{id:"minecraft:player_head",count:1,components:{"minecraft:profile":{id:[119585825,206784598,-1119495979,-520523912],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjhiMjU1MjJjMzFiZmU0Y2VhMTAxMDA4MGQ1YTFiOWIwOGU3NWJhZTUzOGRhODk3MmNiZGQ2YTk0Mzk5MjEyYSJ9fX0="}]},"minecraft:custom_data":{gm4_liquid_minecarts:{liquid_tag:"null"}}}},transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0d,0.7275d,0.0d],scale:[0.83d,0.83d,0.83d]},item_display:"head"}]}
tp @e[type=command_block_minecart, distance=..0.1, tag=gm4_new_machine] @s
scoreboard players set @e[distance=..2, tag=gm4_new_machine] gm4_entity_version 2
execute as @e[type=command_block_minecart, distance=..0.1, tag=gm4_new_machine, limit=1] run function gm4_liquid_minecarts:liquid_value_update

# clean up
kill @s
tag @e[distance=..2] remove gm4_new_machine
