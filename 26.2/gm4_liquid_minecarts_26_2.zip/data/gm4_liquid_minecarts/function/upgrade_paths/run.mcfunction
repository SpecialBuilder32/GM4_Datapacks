execute if score liquid_minecarts gm4_earliest_version matches ..107999 run function gm4_liquid_minecarts:upgrade_paths/1.8
execute if score liquid_minecarts gm4_earliest_version matches ..107999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
