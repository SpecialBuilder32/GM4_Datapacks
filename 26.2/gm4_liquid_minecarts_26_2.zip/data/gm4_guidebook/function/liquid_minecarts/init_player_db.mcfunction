execute if entity @s[advancements={gm4_guidebook:liquid_minecarts/unlock/crafting=true}] run function gm4_guidebook:liquid_minecarts/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:liquid_minecarts/unlock/usage=true}] run function gm4_guidebook:liquid_minecarts/rewards/unlock/usage
return 1
