tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Tower Structures]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Tower Structures",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.tower_structures",fallback:"A custom terrain expansion pack that adds new tower structures to the world.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:tower_structures/display/description
function gm4_guidebook:tower_structures/rewards/unlock/description
