execute if entity @s[advancements={gm4_guidebook:tower_structures/unlock/description=true}] run function gm4_guidebook:tower_structures/rewards/unlock/description
return 1
