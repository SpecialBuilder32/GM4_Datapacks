# Credits

## Creator
- Thanathor

## Icon Design
- Hozz
