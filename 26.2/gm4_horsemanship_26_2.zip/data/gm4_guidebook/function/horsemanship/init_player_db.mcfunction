execute if entity @s[advancements={gm4_guidebook:horsemanship/unlock/description=true}] run function gm4_guidebook:horsemanship/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:horsemanship/unlock/wings=true}] run function gm4_guidebook:horsemanship/rewards/unlock/wings
execute if entity @s[advancements={gm4_guidebook:horsemanship/unlock/feeding=true}] run function gm4_guidebook:horsemanship/rewards/unlock/feeding
return 1
