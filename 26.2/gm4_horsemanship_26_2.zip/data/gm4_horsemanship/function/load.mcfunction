execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. if score gm4_forceload load.status matches 1 if score gm4_forceload_minor load.status matches 1.. run scoreboard players set gm4_horsemanship load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. if score gm4_forceload load.status matches 1 if score gm4_forceload_minor load.status matches 1.. run scoreboard players set gm4_horsemanship_minor load.status 0
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Horsemanship",id:"gm4_horsemanship",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Horsemanship",id:"gm4_horsemanship",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 9.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Horsemanship",id:"gm4_horsemanship",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute unless score gm4_forceload load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Horsemanship",id:"gm4_horsemanship",require:"lib_forceload",require_id:"gm4_forceload"}
execute if score gm4_forceload load.status matches 1.. unless score gm4_forceload load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Horsemanship",id:"gm4_horsemanship",require:"lib_forceload",require_id:"gm4_forceload",require_ver:"1.1.0"}
execute if score gm4_forceload load.status matches 1 unless score gm4_forceload_minor load.status matches 1.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Horsemanship",id:"gm4_horsemanship",require:"lib_forceload",require_id:"gm4_forceload",require_ver:"1.1.0"}
execute unless score gm4_horsemanship load.status matches 1.. run scoreboard players set gm4_horsemanship load.status -1

execute if score gm4_horsemanship load.status matches 1 run function gm4_horsemanship:init
execute unless score gm4_horsemanship load.status matches 1 run schedule clear gm4_horsemanship:main
execute unless score gm4_horsemanship load.status matches 1 run schedule clear gm4_horsemanship:tick
