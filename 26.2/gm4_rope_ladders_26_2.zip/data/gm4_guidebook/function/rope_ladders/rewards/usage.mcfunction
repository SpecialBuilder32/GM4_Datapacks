tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Rope Ladders]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Rope Ladders",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.rope_ladders",fallback:"Climbing downward has never been easier!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:rope_ladders/display/usage
function gm4_guidebook:rope_ladders/rewards/unlock/usage
