execute if entity @s[advancements={gm4_guidebook:rope_ladders/unlock/usage=true}] run function gm4_guidebook:rope_ladders/rewards/unlock/usage
return 1
