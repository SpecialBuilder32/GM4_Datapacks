# @s = interacted rcd
# at player that interacts with a rcd interaction while holding ladder
# run from function: gm4_rope_ladders:mechanics/ladder_placement/interact_right_click_detection

# fail if different gametime
execute store result score $gametime gm4_rol_data run time query gametime
execute store result score $check_gametime gm4_rol_data run data get entity @s interaction.timestamp 1

data remove entity @s interaction
execute unless score $gametime gm4_rol_data = $check_gametime gm4_rol_data run return fail

# continue
execute at @s align xyz positioned ~0.5 ~ ~0.5 run function gm4_rope_ladders:mechanics/ladder_placement/scan_column
