# Credits

## Creator
- [Denniss](https://github.com/Dennis-0)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
