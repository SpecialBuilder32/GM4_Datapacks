execute if entity @s[advancements={gm4_guidebook:podzol_rooting_soil/unlock/description=true}] run function gm4_guidebook:podzol_rooting_soil/rewards/unlock/description
return 1
