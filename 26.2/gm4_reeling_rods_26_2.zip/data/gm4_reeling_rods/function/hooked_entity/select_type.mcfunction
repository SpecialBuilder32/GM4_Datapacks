# Dispatch function for logic on hooked entity
# @s = hooked entity
# at bobber in entity
# run from #gm4_hooked_entity:on_hooked_entity

# fails
execute if score $adventure gm4_reeling_rods.math matches 1 run return fail
execute if entity @s[type=#gm4_reeling_rods:ignore] run return fail
execute if entity @s[tag=smithed.entity] run return fail
execute if data entity @s {Invulnerable:1b} run return fail

# apply barbed damage
execute if data storage gm4_reeling_rods:temp enchanted.barbed if data entity @s Health unless entity @s[type=player, gamemode=creative] run function gm4_reeling_rods:barbed/apply with storage gm4_reeling_rods:temp enchanted.barbed

execute if data storage gm4_reeling_rods:temp enchanted.barbed if entity @s[type=minecraft:tnt_minecart] run return run data modify entity @s fuse set value 0s


# non-dismountable entities


execute if entity @s[type=minecraft:chest_minecart] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/minecart {block:'minecraft:chest'}
execute if entity @s[type=minecraft:furnace_minecart] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/minecart {block:'minecraft:furnace'}
execute if entity @s[type=minecraft:hopper_minecart] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/minecart {block:'minecraft:hopper'}

execute if entity @s[type=minecraft:tnt_minecart] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/minecart {block:'minecraft:tnt'}
execute if entity @s[type=minecraft:acacia_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:acacia_boat'}

execute if entity @s[type=minecraft:bamboo_chest_raft] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:bamboo_raft'}
execute if entity @s[type=minecraft:birch_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:birch_boat'}
execute if entity @s[type=minecraft:cherry_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:cherry_boat'}
execute if entity @s[type=minecraft:dark_oak_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:dark_oak_boat'}
execute if entity @s[type=minecraft:jungle_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:jungle_boat'}
execute if entity @s[type=minecraft:mangrove_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:mangrove_boat'}
execute if entity @s[type=minecraft:oak_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:oak_boat'}
execute if entity @s[type=minecraft:pale_oak_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:pale_oak_boat'}
execute if entity @s[type=minecraft:spruce_chest_boat] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chest_boat/action {boat_type:'minecraft:spruce_boat'}
execute if entity @s[type=minecraft:end_crystal] run return run function gm4_reeling_rods:hooked_entity/end_crystal

execute if entity @s[type=minecraft:glow_item_frame] run return run function gm4_reeling_rods:hooked_entity/item_frame {type:'minecraft:glow_item_frame'}
execute if entity @s[type=minecraft:item_frame] run return run function gm4_reeling_rods:hooked_entity/item_frame {type:'minecraft:item_frame'}

execute if entity @s[type=minecraft:leash_knot] run return run function gm4_reeling_rods:hooked_entity/leash_knot/action
execute if entity @s[type=minecraft:painting] run return run function gm4_reeling_rods:hooked_entity/painting
# dismounting logic
execute if function gm4_reeling_rods:hooked_entity/is_passenger run return run ride @s dismount
# dismountable entities
execute if entity @s[type=#gm4_reeling_rods:chested_horse] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/chested_horse
execute if entity @s[type=#gm4_reeling_rods:llamas] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/llama
execute if entity @s[type=#gm4_reeling_rods:steal_body] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/stealable/steal_slot/body
execute if entity @s[type=#gm4_reeling_rods:steal_body_and_saddle] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/stealable/steal_body_and_saddle
execute if entity @s[type=#gm4_reeling_rods:steal_equipment] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/stealable/steal_equipment
execute if entity @s[type=#gm4_reeling_rods:steal_hand] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/stealable/steal_hand
execute if entity @s[type=#gm4_reeling_rods:steal_saddle] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/stealable/steal_slot/saddle
execute if entity @s[type=minecraft:bee] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/bee
execute if entity @s[type=minecraft:enderman] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/enderman/action
execute if entity @s[type=minecraft:mooshroom] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/mooshroom
execute if entity @s[type=minecraft:sheep] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/sheep
execute if entity @s[type=minecraft:snow_golem] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/snow_golem
execute if entity @s[type=minecraft:sulfur_cube] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/sulfur_cube
execute if entity @s[type=minecraft:villager] run return run execute if data storage gm4_reeling_rods:temp enchanted.reeling run function gm4_reeling_rods:reeling/villager/action
execute if entity @s[type=minecraft:shulker] run return run function gm4_reeling_rods:hooked_entity/shulker
