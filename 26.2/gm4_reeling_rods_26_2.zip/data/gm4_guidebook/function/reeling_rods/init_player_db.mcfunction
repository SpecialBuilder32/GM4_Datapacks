execute if entity @s[advancements={gm4_guidebook:reeling_rods/unlock/description=true}] run function gm4_guidebook:reeling_rods/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:reeling_rods/unlock/reeling=true}] run function gm4_guidebook:reeling_rods/rewards/unlock/reeling
execute if entity @s[advancements={gm4_guidebook:reeling_rods/unlock/barbed=true}] run function gm4_guidebook:reeling_rods/rewards/unlock/barbed
return 1
