tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Lavish Livestock]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Lavish Livestock",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.lavish_livestock",fallback:"Selectively breed your livestock for increased yields! Commercialize your farming!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:lavish_livestock/display/display
function gm4_guidebook:lavish_livestock/rewards/unlock/display
