execute if entity @s[advancements={gm4_guidebook:blossoming_pots/unlock/display=true}] run function gm4_guidebook:blossoming_pots/rewards/unlock/display
return 1
