execute if score blossoming_pots gm4_earliest_version matches ..300999 run function gm4_blossoming_pots:upgrade_paths/3.1
execute if score blossoming_pots gm4_earliest_version matches ..303999 run function gm4_blossoming_pots:upgrade_paths/3.4
execute if score blossoming_pots gm4_earliest_version matches ..303999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
