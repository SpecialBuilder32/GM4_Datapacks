# <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="GM4 Logo" width="32" /> Display Frames by Gamemode 4

Have you ever wanted to add invisible item frames to your survival world without feeling like you're cheating? This data pack will let you splash your item frames with invisibility potions to make them permanently invisible when displaying an item! 

<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/gm4_display_frames/images/display_frames_example.png" alt="Display frames in use" height="350"/>   

### Features
- When an invisibility potion is thrown in the vicinity of an item frame, it makes the item frame go invisible when displaying an item.
- When an invisible item frame is holding no item it will turn visible but show invisible potion effect particles to indicate that it is still able to turn invisible again.
- Adds a new custom advancement for turning an item frame invisible.

### More Info
[<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_wiki_logo.png" alt="Gamemode 4 Wiki Logo" width="40" align="center"/> **Read the Wiki**](https://wiki.gm4.co/wiki/Display_Frames)

### Credits
- Creators: [BPR](https://bsky.app/profile/bpr02.com), TheEpyonProject
- Icon Design: [BPR](https://bsky.app/profile/bpr02.com)

---
## About Gamemode 4 <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="Gamemode 4 Logo" width="20"/>
Gamemode 4 is a series of command-powered creations that are designed to change and enhance the survival experience. All of our modules are designed to work together flawlessly, and are balanced for usage in a survival setting. Pick and choose your favorites from our [website](https://gm4.co), or wherever you get datapacks.