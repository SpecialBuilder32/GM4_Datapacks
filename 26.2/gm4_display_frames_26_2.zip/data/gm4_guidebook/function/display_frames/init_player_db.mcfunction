execute if entity @s[advancements={gm4_guidebook:display_frames/unlock/description=true}] run function gm4_guidebook:display_frames/rewards/unlock/description
return 1
