# Checks for neighboring doors which may also have to be opened alongside this door.
# @s = player that interacted with a door
# at location of the lower half of the door the player has interacted with
# run from gm4_double_doors:crimson/door/right_hinge/north/get_facing

# open this door
function gm4_double_doors:crimson/door/right_hinge/north/toggle

# check for potential neighbouring doors which should also be opened
execute positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:crimson_door[hinge=left, facing=north] run function gm4_double_doors:crimson/door/left_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:crimson_door[hinge=left, facing=south] run function gm4_double_doors:crimson/door/left_hinge/south/toggle
