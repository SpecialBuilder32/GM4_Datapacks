execute if entity @s[advancements={gm4_guidebook:cooler_caves/unlock/cave_changes=true}] run function gm4_guidebook:cooler_caves/rewards/unlock/cave_changes
return 1
