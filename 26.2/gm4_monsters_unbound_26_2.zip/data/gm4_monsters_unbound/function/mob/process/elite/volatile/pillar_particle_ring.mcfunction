# volatile pillar particles
# @s = pillar marker
# at @s rotated ~x ~
# run from clocks/elite/pillaer_process
# run from here

execute if score @s gm4_mu_data matches 2 run particle dust_color_transition{from_color:[0.667d,0.0d,0.667d],scale:1,to_color:[0.0d,0.0d,0.0d]} ^ ^ ^2.25 0 0 0 1 0 normal
execute if score @s gm4_mu_data matches 3 run particle dust_color_transition{from_color:[0.667d,0.0d,0.667d],scale:1,to_color:[0.0d,0.0d,0.0d]} ^ ^ ^2.5 0 0 0 1 0 normal
execute if score @s gm4_mu_data matches 4 run particle dust_color_transition{from_color:[0.667d,0.0d,0.667d],scale:1,to_color:[0.0d,0.0d,0.0d]} ^ ^ ^2.75 0 0 0 1 0 normal
execute if score @s gm4_mu_data matches 5 run particle dust_color_transition{from_color:[0.667d,0.0d,0.667d],scale:1,to_color:[0.0d,0.0d,0.0d]} ^ ^ ^3 0 0 0 1 0 normal

scoreboard players remove $particle_ring gm4_mu_data 6
execute if score $particle_ring gm4_mu_data matches 1.. rotated ~6 ~ run function gm4_monsters_unbound:mob/process/elite/volatile/pillar_particle_ring
