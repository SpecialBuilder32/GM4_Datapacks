# process the glacial bomb
# @s = glacial elite death marker
# at @s
# run from clocks/elite/glacial_death

# before show warning
particle dust{color:[0.725d,0.91d,0.918d],scale:3} ~ ~ ~ 0.04 0.04 0.04 0 4 normal
particle snowflake ~ ~ ~ 1.75 1.75 1.75 0 7 normal
scoreboard players set $frost_ring_yaw gm4_mu_data 0
execute if score @s gm4_mu_data matches ..360 rotated 0 80 run function gm4_monsters_unbound:mob/process/elite/glacial/warning_yaw_loop

# explode after 2 seconds
scoreboard players add @s gm4_mu_data 20

playsound minecraft:block.snow.break hostile @a[distance=..4.81] ~ ~ ~ 1.55 1.2
playsound minecraft:block.snow.fall hostile @a[distance=..4.81] ~ ~ ~ 2 0.75
playsound minecraft:block.snow.fall hostile @a[distance=4.81..16] ~ ~ ~ 1 0.6

execute if score @s gm4_mu_data matches 400.. run return run function gm4_monsters_unbound:mob/process/elite/glacial/explode
scoreboard players set $keep_tick.elite_glacial_death gm4_mu_keep_tick 1
