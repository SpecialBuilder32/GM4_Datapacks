execute if entity @s[advancements={gm4_guidebook:dangerous_dungeons/unlock/description=true}] run function gm4_guidebook:dangerous_dungeons/rewards/unlock/description
return 1
