tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Teleportation Anchors]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Teleportation Anchors",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.teleportation_anchors",fallback:"Suppress and control chorus-based teleportation!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:teleportation_anchors/display/usage_jammer
advancement grant @s only gm4_guidebook:teleportation_anchors/unlock/description
function gm4_guidebook:teleportation_anchors/rewards/unlock/usage_jammer
