execute if entity @s[advancements={gm4_guidebook:teleportation_anchors/unlock/crafting_jammer=true}] run function gm4_guidebook:teleportation_anchors/rewards/unlock/crafting_jammer
execute if entity @s[advancements={gm4_guidebook:teleportation_anchors/unlock/usage_jammer=true}] run function gm4_guidebook:teleportation_anchors/rewards/unlock/usage_jammer
execute if entity @s[advancements={gm4_guidebook:teleportation_anchors/unlock/usage_anchor=true}] run function gm4_guidebook:teleportation_anchors/rewards/unlock/usage_anchor
return 1
