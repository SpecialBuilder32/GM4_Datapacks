execute if score teleportation_anchors gm4_earliest_version matches ..106999 run function gm4_teleportation_anchors:upgrade_paths/1.7
execute if score teleportation_anchors gm4_earliest_version matches ..106999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
