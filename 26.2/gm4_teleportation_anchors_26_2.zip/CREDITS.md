# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Updated By
- [runcows](https://bsky.app/profile/runcows.bsky.social)

## Icon Design
- Hozz
