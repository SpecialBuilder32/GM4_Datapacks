execute if entity @s[advancements={gm4_guidebook:book_binders/unlock/rebinding=true}] run function gm4_guidebook:book_binders/rewards/unlock/rebinding
return 1
