# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)
- [BPR](https://bsky.app/profile/bpr02.com)
- TheEpyonProject

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
