execute if entity @s[advancements={gm4_guidebook:lightning_in_a_bottle/unlock/description=true}] run function gm4_guidebook:lightning_in_a_bottle/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:lightning_in_a_bottle/unlock/obtaining=true}] run function gm4_guidebook:lightning_in_a_bottle/rewards/unlock/obtaining
execute if entity @s[advancements={gm4_guidebook:lightning_in_a_bottle/unlock/usage=true}] run function gm4_guidebook:lightning_in_a_bottle/rewards/unlock/usage
return 1
