
























data merge block ~ ~ ~ {CustomName:{translate:"gm4.second",fallback:"%1$s",with:[{translate:"container.gm4.liquid_tank.liab_lightning",fallback:"Lightning Tank"},[{translate:"gui.gm4.liquid_tank",fallback:"",font:"gm4:container_gui",color:"white"},{translate:"container.gm4.liquid_tank.liab_lightning",fallback:"Lightning Tank",font:"gm4:default",color:"#404040"}]]}}
summon item_display ~ ~ ~ {CustomName:"gm4_liquid_tank_liquid_display",Tags:["gm4_liquid_tank_liquid_display","smithed.entity","smithed.strict"],item:{id:"player_head",count:1b,components:{"minecraft:profile":{id:[2130271109,-1138570753,-1614258158,-884567317],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTYzODMwMzcyNDQ2NywKICAicHJvZmlsZUlkIiA6ICI4MmM2MDZjNWM2NTI0Yjc5OGI5MWExMmQzYTYxNjk3NyIsCiAgInByb2ZpbGVOYW1lIiA6ICJOb3ROb3RvcmlvdXNOZW1vIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2Y3ZjA1OWRiZTJhZDIxZTlmMzZiY2U3NmYyY2YyOGI5ZDdlOGFmN2Q4OTE0MDdhYWYwYTE2OTk3MTJhMmE2YmEiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="}]}}},transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.2185f,0.0f],scale:[0.83d,0.83d,0.83d]},item_display:"head"}
data modify entity @s data.gm4_liquid_tanks.liquid_tag set value "gm4_lt_liab_lightning"
scoreboard players set @s gm4_lt_max 300
tag @s add gm4_lt_liab_lightning
tag @s remove gm4_lt_empty
