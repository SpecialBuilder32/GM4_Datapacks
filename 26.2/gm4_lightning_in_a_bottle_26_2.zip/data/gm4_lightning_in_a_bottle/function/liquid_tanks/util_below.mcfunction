
























tag @s add gm4_processing_tank
execute if score @s[tag=gm4_lt_liab_lightning] gm4_lt_value matches 1.. as @e[type=!#gm4:non_living, type=!armor_stand, tag=!smithed.strict, limit=1, dx=0] unless entity @s[gamemode=spectator] unless entity @s[predicate=gm4_lightning_in_a_bottle:on_fire] run function gm4_lightning_in_a_bottle:liquid_tanks/util/lightning
tag @s remove gm4_processing_tank
