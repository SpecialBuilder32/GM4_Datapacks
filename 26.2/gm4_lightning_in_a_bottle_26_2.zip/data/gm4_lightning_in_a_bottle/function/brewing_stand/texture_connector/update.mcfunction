# @s = @e[type=item_display,tag=gm4_lightning_rod_texture_connector]
# at @s
# run from brewing_stand/texture_connector/process

# kill if unneeded
execute unless block ~ ~-0.1 ~ minecraft:brewing_stand run return run kill @s
execute unless block ~ ~ ~ #minecraft:lightning_rods run return run kill @s

# update texture
scoreboard players set $texture_changed gm4_liab_data 0
# normal
execute unless score @s gm4_liab.oxidization matches 1 if block ~ ~ ~ #gm4_lightning_in_a_bottle:normal_lightning_rod store success score $texture_changed gm4_liab_data run data modify entity @s item.components merge value {"minecraft:profile":{id:[1196754309,1130089731,-1851853423,152678880],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTYzNzc3MDAzOTc2OCwKICAicHJvZmlsZUlkIiA6ICJmODJmNTQ1MDIzZDA0MTFkYmVlYzU4YWI4Y2JlMTNjNyIsCiAgInByb2ZpbGVOYW1lIiA6ICJSZXNwb25kZW50cyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS81YzEzZjIxN2U5NmJmY2VhNjIwZTc3YTIzNjRjYTBkNmE0ZTdhN2UwOGMzNzAzNzI3ODI4MTQ4ZjQxNjM0YmVjIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="}]}}
execute if score $texture_changed gm4_liab_data matches 1 run return run scoreboard players set @s gm4_liab.oxidization 1
# exposed
execute unless score @s gm4_liab.oxidization matches 2 if block ~ ~ ~ #gm4_lightning_in_a_bottle:exposed_lightning_rod store success score $texture_changed gm4_liab_data run data modify entity @s item.components merge value {"minecraft:profile":{id:[1105086427,-2014818885,-2050456398,1819890536],properties:[{name:"textures",value:"eyd0ZXh0dXJlcyc6IHsnU0tJTic6IHsndXJsJzogJ2h0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjU0ZTFmZmZlNzNiMjljMGU1NzVhOTg2OTI3OTJhZTIxYzQwNDUzZmMxNDRiYjYxZjE4ZDBmZjhmMjY3N2IxMSd9fX0="}]}}
execute if score $texture_changed gm4_liab_data matches 1 run return run scoreboard players set @s gm4_liab.oxidization 2
# weathered
execute unless score @s gm4_liab.oxidization matches 3 if block ~ ~ ~ #gm4_lightning_in_a_bottle:weathered_lightning_rod store success score $texture_changed gm4_liab_data run data modify entity @s item.components merge value {"minecraft:profile":{id:[-53579126,-1276100194,-1254675310,1810892024],properties:[{name:"textures",value:"eyd0ZXh0dXJlcyc6IHsnU0tJTic6IHsndXJsJzogJ2h0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTExYjlhYjJlZmY4ZDMzYzU3ZWUyMjVjYWQ5ZmNkMTFmN2JmN2I4MzI2YWJlMTVhOWQ1MzUwNjNmOTZkOGZjMCd9fX0="}]}}
execute if score $texture_changed gm4_liab_data matches 1 run return run scoreboard players set @s gm4_liab.oxidization 3
# oxidized
execute unless score @s gm4_liab.oxidization matches 4 if block ~ ~ ~ #gm4_lightning_in_a_bottle:oxidized_lightning_rod store success score $texture_changed gm4_liab_data run data modify entity @s item.components merge value {"minecraft:profile":{id:[-1160792602,948128354,-1355641425,1430620480],properties:[{name:"textures",value:"eyd0ZXh0dXJlcyc6IHsnU0tJTic6IHsndXJsJzogJ2h0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDY1ZGQ5Njg5MzIyNDZjZjgwODA3Y2E2NmY4M2Y0MThjNjc5YTIzMjI5MDdiYmNkMWYxN2I4ZTQ3NWUwYzE4J319fQ=="}]}}
execute if score $texture_changed gm4_liab_data matches 1 run return run scoreboard players set @s gm4_liab.oxidization 4
