execute if entity @s[advancements={gm4_guidebook:tunnel_bores/unlock/crafting=true}] run function gm4_guidebook:tunnel_bores/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:tunnel_bores/unlock/usage=true}] run function gm4_guidebook:tunnel_bores/rewards/unlock/usage
return 1
