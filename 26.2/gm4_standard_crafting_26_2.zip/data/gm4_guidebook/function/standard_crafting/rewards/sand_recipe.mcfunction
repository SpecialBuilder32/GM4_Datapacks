tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Standard Crafting]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Standard Crafting",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.standard_crafting",fallback:"A crafting recipe pack that adds some nifty new recipes to the game.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:standard_crafting/display/sand_recipe
function gm4_guidebook:standard_crafting/rewards/unlock/sand_recipe
