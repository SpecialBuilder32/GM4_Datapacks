execute if score disassemblers gm4_earliest_version matches ..205999 run function gm4_disassemblers:upgrade_paths/2.6
execute if score disassemblers gm4_earliest_version matches ..205999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
