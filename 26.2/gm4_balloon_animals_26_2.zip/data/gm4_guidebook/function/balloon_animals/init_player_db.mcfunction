execute if entity @s[advancements={gm4_guidebook:balloon_animals/unlock/description=true}] run function gm4_guidebook:balloon_animals/rewards/unlock/description
return 1
