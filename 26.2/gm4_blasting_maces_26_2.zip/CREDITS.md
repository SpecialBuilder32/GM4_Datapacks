# Credits

## Creator
- Drodo

## Icon Design
- [Lune6](https://bsky.app/profile/lune6.bsky.social)
