tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Animi Shamir]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Animi Shamir",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.animi_shamir",fallback:"Adds the Animi Shamir to Metallurgy. Items with Animi will respawn with you when you die!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:animi_shamir/display/usage
function gm4_guidebook:animi_shamir/rewards/unlock/usage
