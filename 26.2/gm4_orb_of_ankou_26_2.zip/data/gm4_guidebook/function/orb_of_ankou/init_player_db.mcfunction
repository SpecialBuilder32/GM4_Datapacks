execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/forge_creation=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/forge_creation
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/shard_creation=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/shard_creation
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/shard_usage=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/shard_usage
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/orb_crafting=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/orb_crafting
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/orb_fusing=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/orb_fusing
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/orb_usage=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/orb_usage
execute if entity @s[advancements={gm4_guidebook:orb_of_ankou/unlock/pneuma_descriptions=true}] run function gm4_guidebook:orb_of_ankou/rewards/unlock/pneuma_descriptions
return 1
