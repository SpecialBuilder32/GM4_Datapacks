data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "orb_of_ankou"
data modify storage gm4_guidebook:temp unlocking.target_page set value 9
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 14
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 10
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 15
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 11
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 16
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_2"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 12
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 17
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_3"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 13
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 18
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_4"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 14
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 19
data modify storage gm4_guidebook:temp unlocking.source_page set value "pneuma_descriptions_5"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
