# @s = sonic_boomer marker
# run from tick

particle minecraft:sonic_boom ~ ~ ~ 0 0 0 1 1
scoreboard players set $target_found gm4_pneuma_data 0
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[type=!#gm4:non_living, tag=!gm4_oa_shrieker, dx=0.5, dy=0.5, dz=0.5] run function gm4_orb_of_ankou:pneumas/shrieking/boom
scoreboard players add $ray gm4_pneuma_data 1

execute unless score $ray gm4_pneuma_data matches 15.. unless score $target_found gm4_pneuma_data matches 1.. positioned ^ ^ ^1 run function gm4_orb_of_ankou:pneumas/shrieking/find_target
