# @s = wither decorative particle
# run from soul_forge/process

teleport ^ ^ ^0.4
particle minecraft:dust{color:[0.071d,0.0d,0.161d],scale:1} ~ ~ ~ 0 0 0 0.005 3
particle minecraft:dust{color:[0.475d,0.639d,0.443d],scale:1} ~ ~ ~ 0 0 0 0.005 1
execute positioned ~ ~-1 ~ if entity @e[type=armor_stand, tag=gm4_soul_forge, distance=..3] run kill @s
scoreboard players add @s gm4_oa_marker 16
kill @s[scores={gm4_oa_marker=200..}]
