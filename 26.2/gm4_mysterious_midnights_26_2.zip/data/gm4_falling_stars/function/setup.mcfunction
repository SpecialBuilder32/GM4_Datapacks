#called upon start of a rare mysterious midnight. Used to select this expansion by chance.

summon minecraft:area_effect_cloud ~ ~ ~ {CustomName:"gm4_falling_stars",Tags:["gm4_mysterious_midnights_expansion","gm4_falling_stars"],Duration:18000,Radius:0.0f,custom_particle:{type:"minecraft:block",block_state:"minecraft:air"}}
