# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
- [Thanathor](https://twitter.com/The_Thanathor)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
