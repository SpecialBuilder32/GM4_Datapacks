# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz
