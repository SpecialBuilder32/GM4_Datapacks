# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- Federick90
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- Hozz
