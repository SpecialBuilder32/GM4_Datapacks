# Credits

## Creators
- [Bloo](https://twitter.com/Bloo_dev)
- [Sparks](https://twitter.com/SelcouthSparks)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
