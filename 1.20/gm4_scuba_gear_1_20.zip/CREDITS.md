# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
