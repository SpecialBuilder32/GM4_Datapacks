# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [Misode](https://twitter.com/misode_)

## Icon Design
- Hozz
