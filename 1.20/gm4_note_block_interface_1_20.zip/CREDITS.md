# Credits

## Creator
- [Scommander](https://github.com/Scommander)

## Updated by
- [Denniss](https://twitter.com/Dennis2p_)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
