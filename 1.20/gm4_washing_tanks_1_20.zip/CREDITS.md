# Credits

## Creators
- [Bunnygamers](https://twitter.com/BunnygamersMC)
- [Misode](https://twitter.com/misode_)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
